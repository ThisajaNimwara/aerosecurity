import { create } from "zustand";

type UiState = {
  clearanceOpen: boolean;
  docsOpen: boolean;
  setClearanceOpen: (open: boolean) => void;
  setDocsOpen: (open: boolean) => void;
};

export const useUi = create<UiState>((set) => ({
  clearanceOpen: false,
  docsOpen: false,
  setClearanceOpen: (clearanceOpen) => set({ clearanceOpen }),
  setDocsOpen: (docsOpen) => set({ docsOpen }),
}));
