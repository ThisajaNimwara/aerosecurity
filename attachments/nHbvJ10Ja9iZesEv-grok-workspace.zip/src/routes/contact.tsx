import { createFileRoute } from "@tanstack/react-router";
import { Radio, ShieldCheck, Timer } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { PageHeader } from "@/components/landing/page-header";
import { Reveal } from "@/components/landing/reveal";
import { ClearanceForm } from "@/components/landing/clearance-form";
import { COMPLIANCE } from "@/lib/site";

export const Route = createFileRoute("/contact")({ component: ContactPage });

const CHANNELS = [
  {
    icon: ShieldCheck,
    title: "Cleared channel",
    body: "Every request routes to a specialist over an authenticated, encrypted path — no cold inboxes.",
  },
  {
    icon: Timer,
    title: "Response time",
    body: "Official-domain requests are triaged within one business day.",
  },
  {
    icon: Radio,
    title: "Active programs",
    body: "Already under contract? Use your existing program liaison instead of this form.",
  },
] as const;

function ContactPage() {
  return (
    <PageShell>
      <PageHeader
        index="05"
        label="Contact"
        title="Open a secure channel."
        intro="Tell us what you are trying to protect — a UAV fleet, a constellation, or a tactical avionics stack — and a specialist will follow up on a cleared line."
      />

      <div className="mx-auto max-w-5xl px-4 pb-24 sm:px-6 sm:pb-32">
        <div className="grid gap-10 border-t border-border pt-12 lg:grid-cols-[1fr_0.85fr] lg:gap-16">
          <Reveal>
            <div className="border border-border bg-surface p-6 sm:p-8">
              <p className="font-mono text-xs uppercase tracking-[0.18em] text-fg">
                Clearance request
              </p>
              <p className="mt-1 font-mono text-micro uppercase tracking-[0.14em] text-dim">
                Classification: CUI // NOFORN
              </p>
              <div className="mt-6">
                <ClearanceForm idPrefix="contact" />
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <div className="flex flex-col gap-6">
              {CHANNELS.map((c) => (
                <div
                  key={c.title}
                  className="flex gap-4 border-b border-border pb-6 last:border-b-0 last:pb-0"
                >
                  <span className="flex size-10 shrink-0 items-center justify-center border border-border bg-surface text-primary">
                    <c.icon className="size-4.5" strokeWidth={1.6} />
                  </span>
                  <div>
                    <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-fg">
                      {c.title}
                    </h2>
                    <p className="mt-1.5 max-w-sm text-sm leading-relaxed text-muted">
                      {c.body}
                    </p>
                  </div>
                </div>
              ))}

              <div className="mt-2">
                <p className="font-mono text-micro uppercase tracking-[0.16em] text-dim">
                  Compliance
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {COMPLIANCE.map((badge) => (
                    <span
                      key={badge}
                      className="border border-border px-2 py-1 font-mono text-micro uppercase tracking-[0.12em] text-dim"
                    >
                      {badge}
                    </span>
                  ))}
                </div>
              </div>

              <dl className="mt-4 grid gap-px border border-border bg-border">
                <div className="bg-surface px-5 py-4">
                  <dt className="font-mono text-micro uppercase tracking-[0.16em] text-dim">
                    Engineering
                  </dt>
                  <dd className="mt-1 text-sm text-fg">El Segundo, California</dd>
                </div>
                <div className="bg-surface px-5 py-4">
                  <dt className="font-mono text-micro uppercase tracking-[0.16em] text-dim">
                    Range
                  </dt>
                  <dd className="mt-1 text-sm text-fg">Colorado Springs, Colorado</dd>
                </div>
              </dl>
            </div>
          </Reveal>
        </div>
      </div>
    </PageShell>
  );
}
