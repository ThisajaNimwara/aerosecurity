import * as React from "react";
import { cn } from "@/lib/utils";

function Label({ className, ...props }: React.ComponentProps<"label">) {
  return (
    <label
      className={cn(
        "font-mono text-micro uppercase tracking-[0.18em] text-muted",
        className,
      )}
      {...props}
    />
  );
}

export { Label };
