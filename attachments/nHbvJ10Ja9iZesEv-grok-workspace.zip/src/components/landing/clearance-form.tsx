import { type FormEvent, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const DOMAINS = [
  { value: "uav", label: "UAV fleet" },
  { value: "satcom", label: "SATCOM / ISL" },
  { value: "avionics", label: "Tactical avionics" },
  { value: "isl", label: "LEO constellation" },
  { value: "other", label: "Other / classified" },
] as const;

export function ClearanceForm({
  onSuccess,
  idPrefix = "clr",
}: {
  onSuccess?: () => void;
  idPrefix?: string;
}) {
  const [name, setName] = useState("");
  const [org, setOrg] = useState("");
  const [email, setEmail] = useState("");
  const [domain, setDomain] = useState("uav");
  const [notes, setNotes] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (name.trim().length < 2 || org.trim().length < 2) {
      toast.error("Name and organization are required.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Enter an official email.");
      return;
    }
    const payload = { name, org, email, domain, notes, at: new Date().toISOString() };
    try {
      const prev = JSON.parse(localStorage.getItem("aero.clearance") ?? "[]") as unknown[];
      localStorage.setItem("aero.clearance", JSON.stringify([...prev, payload]));
    } catch {
      /* ignore quota */
    }
    toast.success("Clearance request queued.", {
      description: "A specialist will respond on a secure channel.",
    });
    setName("");
    setOrg("");
    setEmail("");
    setNotes("");
    onSuccess?.();
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-4">
      <div className="flex flex-col gap-1.5">
        <Label htmlFor={`${idPrefix}-name`}>Full name</Label>
        <Input
          id={`${idPrefix}-name`}
          value={name}
          onChange={(e) => setName(e.target.value)}
          autoComplete="name"
          required
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor={`${idPrefix}-org`}>Organization</Label>
        <Input
          id={`${idPrefix}-org`}
          value={org}
          onChange={(e) => setOrg(e.target.value)}
          autoComplete="organization"
          required
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor={`${idPrefix}-email`}>Official email</Label>
        <Input
          id={`${idPrefix}-email`}
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoComplete="email"
          required
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor={`${idPrefix}-domain`}>Asset class</Label>
        <select
          id={`${idPrefix}-domain`}
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          className="flex h-11 w-full border border-border bg-bg px-3 font-mono text-sm text-fg focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary focus-visible:outline-none"
        >
          {DOMAINS.map((d) => (
            <option key={d.value} value={d.value}>
              {d.label}
            </option>
          ))}
        </select>
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor={`${idPrefix}-notes`}>What are you trying to secure? (optional)</Label>
        <textarea
          id={`${idPrefix}-notes`}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={4}
          className="flex w-full resize-none border border-border bg-bg px-3 py-2.5 font-mono text-sm text-fg placeholder:text-dim focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary focus-visible:outline-none"
          placeholder="Airframe, constellation, or program details."
        />
      </div>
      <Button type="submit" className="mt-2">
        Submit request
      </Button>
    </form>
  );
}
