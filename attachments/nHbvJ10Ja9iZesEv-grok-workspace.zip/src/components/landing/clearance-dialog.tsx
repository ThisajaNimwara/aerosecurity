import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ClearanceForm } from "@/components/landing/clearance-form";
import { useUi } from "@/lib/ui-store";

export function ClearanceDialog() {
  const open = useUi((s) => s.clearanceOpen);
  const setOpen = useUi((s) => s.setClearanceOpen);

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-bg/80 backdrop-blur-sm" />
        <Dialog.Content className="fixed top-1/2 left-1/2 z-50 w-[min(92vw,480px)] max-h-[90vh] -translate-x-1/2 -translate-y-1/2 overflow-y-auto border border-border bg-surface shadow-[var(--shadow-card)] focus:outline-none">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <div>
              <Dialog.Title className="font-mono text-xs uppercase tracking-[0.18em] text-fg">
                Clearance request
              </Dialog.Title>
              <Dialog.Description className="mt-1 font-mono text-micro uppercase tracking-[0.14em] text-dim">
                Classification: CUI // NOFORN
              </Dialog.Description>
            </div>
            <Dialog.Close asChild>
              <Button variant="ghost" size="icon" aria-label="Close">
                <X />
              </Button>
            </Dialog.Close>
          </div>
          <div className="px-5 py-5">
            <ClearanceForm onSuccess={() => setOpen(false)} />
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
