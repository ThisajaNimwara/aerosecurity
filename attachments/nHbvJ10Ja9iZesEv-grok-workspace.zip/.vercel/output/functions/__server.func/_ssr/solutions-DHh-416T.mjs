import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as SOLUTION_DETAILS } from "./router-DhaH2Qdo.mjs";
import { i as Reveal, r as PageShell, t as Button, u as useUi } from "./reveal-DlvPhQQo.mjs";
import { t as PageHeader } from "./page-header-B6OFR9ws.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/solutions-DHh-416T.js
var import_jsx_runtime = require_jsx_runtime();
function SolutionsPage() {
	const setClearanceOpen = useUi((s) => s.setClearanceOpen);
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		index: "02",
		label: "Solutions",
		title: "Seven capabilities. One control plane.",
		intro: "Every product here ships from the same EDR core — hardened for the specific bus, radio, or airframe it rides on."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl px-4 pb-24 sm:px-6 sm:pb-32",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "flex flex-col",
			children: SOLUTION_DETAILS.map((cap) => {
				const Icon = cap.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					id: cap.id,
					className: "scroll-mt-28 border-t border-border py-14 sm:py-16",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-12 items-center justify-center border border-border bg-surface text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-5",
											strokeWidth: 1.6
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-micro tabular-nums tracking-[0.16em] text-dim",
										children: [cap.index, " / 07"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-micro uppercase tracking-[0.16em] text-signal",
									children: cap.kicker
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl font-semibold tracking-[-0.025em] text-fg sm:text-3xl lg:text-4xl",
								children: cap.nav
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-3xl text-base leading-relaxed text-muted sm:text-lg",
								children: cap.body
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "grid grid-cols-1 gap-px border border-border bg-border sm:grid-cols-3",
								children: cap.specs.map((spec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-surface px-5 py-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-mono text-micro uppercase tracking-[0.16em] text-dim",
										children: spec.k
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-mono text-sm text-fg",
										children: spec.v
									})]
								}, spec.k))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-8 lg:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-mono text-micro uppercase tracking-[0.18em] text-muted",
										children: "Threat"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-fg/85",
										children: cap.problem
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-mono text-micro uppercase tracking-[0.18em] text-muted",
										children: "Control"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-fg/85",
										children: cap.control
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-mono text-micro uppercase tracking-[0.18em] text-muted",
										children: "Fit"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-fg/85",
										children: cap.fit
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2",
									children: cap.platforms.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "border border-border px-2.5 py-1 font-mono text-micro uppercase tracking-[0.12em] text-dim",
										children: p
									}, p))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => setClearanceOpen(true),
									children: "Brief this capability"
								})]
							})
						]
					}) })
				}, cap.id);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex flex-col gap-4 border border-border bg-surface px-6 py-8 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-xl text-base text-fg",
				children: "Not sure which layer you need? A specialist will map the stack to the vehicle."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => {
					navigate({ to: "/contact" });
					window.scrollTo({
						top: 0,
						behavior: "smooth"
					});
				},
				children: "Open a channel"
			})]
		}) })]
	})] });
}
//#endregion
export { SolutionsPage as component };
