import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Reveal, r as PageShell } from "./reveal-DlvPhQQo.mjs";
import { t as PageHeader } from "./page-header-B6OFR9ws.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-3MOwXKI3.js
var import_jsx_runtime = require_jsx_runtime();
var SECTIONS = [
	{
		title: "Use of this site",
		body: "This site is an unclassified marketing surface for aerosecurity.space. It does not grant a license to any software, model, or documentation described here. Capability names and architecture sketches are descriptive, not a specification."
	},
	{
		title: "No operational reliance",
		body: "Telemetry, threat-map events, and statistics shown on this site are demonstrations. They are not a live operational feed and must not be used for flight, targeting, or incident response."
	},
	{
		title: "Export",
		body: "Some products described here may be subject to the ITAR or EAR. Access by foreign persons may require authorization. See Export Control."
	},
	{
		title: "Limitation",
		body: "To the extent permitted by law, aerosecurity.space provides this site as-is. Program terms, if any, live in a separately executed agreement."
	}
];
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		index: "07",
		label: "Legal",
		title: "Terms of use.",
		intro: "Unclassified marketing only. Operational use requires a contract and a cleared channel."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-3xl px-4 pb-24 sm:px-6 sm:pb-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-10 border-t border-border pt-12",
			children: SECTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-semibold tracking-[-0.02em] text-fg",
				children: s.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base leading-relaxed text-muted",
				children: s.body
			})] }, s.title))
		})
	})] });
}
//#endregion
export { TermsPage as component };
