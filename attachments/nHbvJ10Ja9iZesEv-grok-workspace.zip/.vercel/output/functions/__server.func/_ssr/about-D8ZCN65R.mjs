import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as PARTNERSHIPS, i as FACTS, n as CAREERS } from "./router-DhaH2Qdo.mjs";
import { i as Reveal, o as Stagger, r as PageShell, s as StaggerItem, t as Button, u as useUi } from "./reveal-DlvPhQQo.mjs";
import { t as PageHeader } from "./page-header-B6OFR9ws.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-D8ZCN65R.js
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	{
		n: "01",
		title: "Instrument the vehicle",
		body: "The EDR agent compiles into the flight image and watches the buses the vehicle already has — 1553, SpaceWire, MAVLink, proprietary RF."
	},
	{
		n: "02",
		title: "Bind the fleet",
		body: "CEMP puts every airframe or bird into a signed enclave so policy, patches, and containment share one control plane."
	},
	{
		n: "03",
		title: "Prove it on the metal",
		body: "The HITL range runs adversary emulation against the same radios and software that fly, before the image ever leaves the hangar."
	},
	{
		n: "04",
		title: "Seal and fly",
		body: "Pre-flight hardening fails closed. On-device agents keep classifying when the ground loop is denied."
	}
];
function AboutPage() {
	const setClearanceOpen = useUi((s) => s.setClearanceOpen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			index: "03",
			label: "About",
			title: "Forged for aerospace. Secured for the future.",
			intro: "A small, cleared team building the cyber-physical control plane for vehicles that cannot fail in the air — or on orbit."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "who-we-are",
			className: "scroll-mt-28 border-t border-border py-16 sm:py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-10 px-4 sm:px-6 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-semibold tracking-[-0.02em] text-fg sm:text-3xl",
						children: "Who we are"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-base leading-relaxed text-muted",
						children: "aerosecurity.space was founded in 2024 by embedded, RF, and offensive-security engineers who had watched classical EDR fail the first time it met a real-time budget. We assume a hostile spectrum and design as if the neighbor on the mesh is already compromised."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-base leading-relaxed text-muted",
						children: "Engineering sits in El Segundo. The range sits in Colorado Springs. Both are facility-cleared. Marketing on this site is unclassified; program work is not."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: .1,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "grid grid-cols-1 gap-px border border-border bg-border sm:grid-cols-2 lg:grid-cols-1",
						children: FACTS.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-surface px-5 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-mono text-micro uppercase tracking-[0.16em] text-dim",
								children: fact.k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm text-fg",
								children: fact.v
							})]
						}, fact.k))
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "what-we-do",
			className: "scroll-mt-28 border-t border-border py-16 sm:py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-semibold tracking-[-0.02em] text-fg sm:text-3xl",
					children: "What we do"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-base leading-relaxed text-muted",
					children: "Dual-use by design. The same agent that rides a NASA cFS stack on orbit hardens a tactical UAV fleet on the edge. Four moves, one platform."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stagger, {
					className: "mt-10 grid grid-cols-1 gap-3 sm:grid-cols-2",
					delay: .06,
					children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaggerItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "h-full border border-border bg-surface p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-micro text-signal",
								children: step.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-lg font-semibold tracking-[-0.02em] text-fg",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								children: step.body
							})
						]
					}) }, step.n))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "careers",
			className: "scroll-mt-28 border-t border-border py-16 sm:py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-semibold tracking-[-0.02em] text-fg sm:text-3xl",
					children: "Careers"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-base leading-relaxed text-muted",
					children: "Open roles rotate with program needs. Tell us where you fit and we route it internally — there is no public ATS sitting in front of the work."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-10 divide-y divide-border border border-border",
					children: CAREERS.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "bg-surface px-5 py-6 sm:px-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-semibold tracking-[-0.02em] text-fg",
										children: job.role
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 font-mono text-micro uppercase tracking-[0.14em] text-dim",
										children: [
											job.site,
											" · ",
											job.type
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-relaxed text-muted",
										children: job.body
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								className: "shrink-0 self-start",
								onClick: () => setClearanceOpen(true),
								children: "Apply"
							})]
						})
					}, job.id))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "investments",
			className: "scroll-mt-28 border-t border-border py-16 sm:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-semibold tracking-[-0.02em] text-fg sm:text-3xl",
						children: "Investments and partnerships"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-2xl text-base leading-relaxed text-muted",
						children: "We work with primes, operators, and strategic investors building for a contested spectrum. If you are evaluating the platform for a program, a partnership, or a funding round, request a secure channel."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stagger, {
						className: "mt-10 grid grid-cols-1 gap-3 lg:grid-cols-3",
						delay: .06,
						children: PARTNERSHIPS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaggerItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "h-full border border-border bg-surface p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-semibold tracking-[-0.02em] text-fg",
								children: p.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								children: p.body
							})]
						}) }, p.title))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: .1,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-8",
							onClick: () => setClearanceOpen(true),
							children: "Request a secure briefing"
						})
					})
				]
			})
		})
	] });
}
//#endregion
export { AboutPage as component };
