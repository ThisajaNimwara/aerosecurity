import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { m as ArrowRight, u as FileText } from "../_libs/lucide-react.mjs";
import { a as MARKETS, d as SOLUTION_DETAILS, f as TELEMETRY_ROWS, i as FACTS, m as __exportAll, p as THREAT_NODES, u as RESEARCH } from "./router-DhaH2Qdo.mjs";
import { r as AnimatePresence, t as useReducedMotion } from "../_libs/framer-motion+[...].mjs";
import { t as motion } from "../_libs/motion.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SectionLabel, c as ZuluClock, i as Reveal, l as cn, o as Stagger, r as PageShell, s as StaggerItem, t as Button, u as useUi } from "./reveal-DlvPhQQo.mjs";
import { t as gsapWithCSS } from "../_libs/gsap.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-PaE6zioR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Canonical hex tokens — keep in lockstep with `@theme` in `src/styles.css`. */
var palette = {
	bg: "#090A0F",
	surface: "#14151C",
	surface2: "#1A1B24",
	border: "#2A2B35",
	primary: "#D92D20",
	signal: "#00FF66",
	fg: "#F8F9FA",
	muted: "#A0AEC0",
	menu: "#ECECE6",
	menuFg: "#101010"
};
/** Static wireframe satellite used while WebGL boots (and as a no-WebGL fallback). */
function HeroFallback() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 640 420",
		className: "h-full w-full opacity-70",
		"aria-hidden": true,
		preserveAspectRatio: "xMidYMid meet",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			fill: "none",
			stroke: palette.signal,
			strokeWidth: "1",
			transform: "translate(360 210) rotate(-18)",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "-48",
					y: "-28",
					width: "96",
					height: "56"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "-200",
					y: "-42",
					width: "132",
					height: "84"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "68",
					y: "-42",
					width: "132",
					height: "84"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "-68",
					y1: "0",
					x2: "-200",
					y2: "0"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "48",
					y1: "0",
					x2: "68",
					y2: "0"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "-200",
					y1: "-14",
					x2: "-68",
					y2: "-14"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "-200",
					y1: "14",
					x2: "-68",
					y2: "14"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "68",
					y1: "-14",
					x2: "200",
					y2: "-14"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "68",
					y1: "14",
					x2: "200",
					y2: "14"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "0",
					cy: "-78",
					r: "22",
					stroke: palette.primary
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "0",
					y1: "-28",
					x2: "0",
					y2: "-56"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "0",
					y1: "28",
					x2: "0",
					y2: "70"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "-10,70 10,70 0,92" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "0",
					cy: "0",
					rx: "150",
					ry: "58",
					opacity: "0.45"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "0",
					cy: "0",
					rx: "190",
					ry: "78",
					opacity: "0.25"
				})
			]
		})
	});
}
function HeroCanvas() {
	const [Scene, setScene] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let alive = true;
		import("./hero-scene-0zNt9LkD.mjs").then((mod) => {
			if (alive) setScene(() => mod.HeroScene);
		}).catch(() => {});
		return () => {
			alive = false;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0",
		children: Scene ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroFallback, {})
	});
}
function randomHexLine() {
	return Array.from({ length: 8 }, () => Math.floor(Math.random() * 256).toString(16).padStart(2, "0").toUpperCase()).join(" ");
}
var STATIC_HEX = [
	"7F 4A 9C 21 00 FF 6A 10",
	"12 B0 44 19 D9 2D 20 AA",
	"0E 91 C3 08 5A 77 BE 4C",
	"A3 F4 7B 12 90 01 6E D8",
	"55 0C 2F 88 13 46 9B E1",
	"C0 17 3D 6A FE 04 29 5B"
];
function HeroTelemetry() {
	const [visible, setVisible] = (0, import_react.useState)(0);
	const [hexLines, setHexLines] = (0, import_react.useState)(STATIC_HEX);
	const reduced = (0, import_react.useMemo)(() => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches, []);
	const listRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (reduced) {
			setVisible(TELEMETRY_ROWS.length);
			return;
		}
		const obj = { n: 0 };
		const tween = gsapWithCSS.to(obj, {
			n: TELEMETRY_ROWS.length,
			duration: TELEMETRY_ROWS.length * .16,
			ease: "none",
			onUpdate: () => setVisible(Math.floor(obj.n))
		});
		return () => {
			tween.kill();
		};
	}, [reduced]);
	(0, import_react.useEffect)(() => {
		if (reduced) return;
		const id = window.setInterval(() => {
			setHexLines((prev) => [...prev.slice(1), randomHexLine()]);
		}, 220);
		return () => window.clearInterval(id);
	}, [reduced]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "hidden w-[min(100%,280px)] shrink-0 border border-border bg-bg/70 p-4 backdrop-blur-sm lg:block",
		"aria-label": "Live telemetry",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-micro uppercase tracking-[0.18em] text-muted",
					children: "SYS / AERO.SEC"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-micro text-signal",
					children: "v4.2.1"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mb-3 h-px bg-border" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				ref: listRef,
				className: "space-y-1.5",
				children: TELEMETRY_ROWS.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between font-mono text-2xs tabular-nums text-muted",
					style: { opacity: i < visible ? 1 : .15 },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						row.id,
						". ",
						row.name
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-signal",
						children: [
							"[",
							row.status,
							"]"
						]
					})]
				}, row.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-3 h-px bg-border" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "font-mono text-micro leading-5 text-signal/70",
				children: hexLines.join("\n")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between font-mono text-micro uppercase tracking-[0.14em] text-dim",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "CRC" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-signal",
					children: "OK"
				})]
			})
		]
	});
}
function Hero() {
	const setClearanceOpen = useUi((s) => s.setClearanceOpen);
	const setDocsOpen = useUi((s) => s.setDocsOpen);
	const [offset, setOffset] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const onMove = (e) => {
			const x = (e.clientX / window.innerWidth - .5) * 16;
			const y = (e.clientY / window.innerHeight - .5) * 10;
			setOffset({
				x,
				y
			});
		};
		window.addEventListener("mousemove", onMove, { passive: true });
		return () => window.removeEventListener("mousemove", onMove);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "top",
		className: "relative min-h-[100svh] overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroCanvas, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("pointer-events-none absolute inset-0 z-0", "bg-linear-to-r from-bg from-15% via-bg/80 to-bg/25", "md:from-20% md:via-bg/70") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 z-0 radial-mesh" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 z-0 tactical-grid opacity-30" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto flex min-h-[100svh] max-w-7xl flex-col justify-center px-4 pt-20 pb-16 sm:px-6 lg:flex-row lg:items-center lg:gap-10 lg:pt-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-3xl",
					style: { transform: `translate3d(${offset.x}px, ${offset.y}px, 0)` },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-5 font-mono text-2xs uppercase tracking-[0.22em] text-signal",
							children: "Aerospace · Defense · Cyber"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-display leading-[0.95] font-semibold tracking-[-0.045em] text-fg uppercase",
							children: "Operational intelligence for next-gen aerospace."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg",
							children: "Hardening autonomous fleets, satellite links, and embedded real-time flight controls against sophisticated cyber threats."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "w-full sm:w-auto",
								onClick: () => setClearanceOpen(true),
								children: ["Deploy Platform", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "w-full sm:w-auto",
								onClick: () => setDocsOpen(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {}), "View Documentation"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "mt-10 grid grid-cols-2 gap-px border border-border bg-border sm:grid-cols-4",
							children: [
								{
									k: "Endpoints",
									v: "14k+"
								},
								{
									k: "Median detect",
									v: "180ms"
								},
								{
									k: "Constellations",
									v: "11"
								},
								{
									k: "Uplink integrity",
									v: "99.99%"
								}
							].map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-bg/80 px-3 py-3 sm:px-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "font-mono text-micro uppercase tracking-[0.16em] text-dim",
									children: stat.k
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 font-mono text-sm tabular-nums text-fg",
									children: stat.v
								})]
							}, stat.k))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroTelemetry, {})]
			})
		]
	});
}
function CornerFrame({ className, active = false }) {
	const tick = cn("absolute h-2.5 w-2.5 border-border transition-colors duration-150", active && "border-primary");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("pointer-events-none absolute inset-0", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn(tick, "top-0 left-0 border-t border-l") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn(tick, "top-0 right-0 border-t border-r") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn(tick, "bottom-0 left-0 border-b border-l") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn(tick, "right-0 bottom-0 border-b border-r") })
		]
	});
}
function ProductMatrix() {
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "platform",
		className: "scroll-mt-20 border-t border-border py-20 sm:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
					index: "02",
					label: "Platform"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 max-w-2xl text-3xl font-semibold tracking-[-0.03em] text-fg sm:text-4xl",
					children: "The product matrix."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-base leading-relaxed text-muted",
					children: "Seven capabilities, one control plane. Built for vehicles that cannot fail in the air — or on orbit."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stagger, {
				className: "mt-10 grid grid-cols-1 gap-3 md:grid-cols-6",
				delay: .08,
				children: SOLUTION_DETAILS.map((cap) => {
					const Icon = cap.icon;
					const featured = cap.index === "01";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaggerItem, {
						className: cn(cap.span),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void navigate({
								to: "/solutions",
								hash: cap.id
							}).then(() => {
								window.setTimeout(() => {
									document.getElementById(cap.id)?.scrollIntoView({
										behavior: "smooth",
										block: "start"
									});
								}, 80);
							}),
							className: "block h-full w-full text-left",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: cn("group relative flex h-full flex-col overflow-hidden border border-border bg-surface p-5 transition-[transform,border-color,box-shadow] duration-200 ease-out sm:p-6", "hover:-translate-y-1 hover:border-primary hover:shadow-[var(--shadow-card-hover)]", featured && "min-h-[280px] lg:min-h-[360px]"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "card-scan pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-200 group-hover:opacity-100",
										"aria-hidden": true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerFrame, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex items-start justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex size-9 items-center justify-center border border-border bg-bg text-muted transition-colors duration-200 group-hover:border-primary group-hover:text-primary",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
												className: "size-4",
												strokeWidth: 1.6
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-micro tabular-nums tracking-[0.14em] text-dim",
											children: [cap.index, " // 07"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: cn("relative mt-5 font-semibold tracking-[-0.02em] text-fg", featured ? "text-2xl sm:text-3xl" : "text-lg"),
										children: cap.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: cn("relative mt-3 leading-relaxed text-muted", featured ? "max-w-md text-base" : "text-sm"),
										children: cap.body
									}),
									featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "relative mt-auto pt-8 font-mono text-micro uppercase tracking-[0.16em] text-signal",
										children: cap.kicker
									}) : null
								]
							})
						})
					}, cap.index);
				})
			})]
		})
	});
}
function Solutions() {
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "solutions",
		className: "scroll-mt-20 border-t border-border py-20 sm:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
					index: "03",
					label: "Solutions"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 max-w-2xl text-3xl font-semibold tracking-[-0.03em] text-fg sm:text-4xl",
					children: "Built for the vehicles that fly."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stagger, {
					className: "mt-10 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4",
					children: MARKETS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaggerItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "h-full border border-border bg-surface p-5 transition-[border-color] duration-150 hover:border-fg/30",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-micro text-signal",
								children: item.index
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 text-lg font-semibold tracking-[-0.02em] text-fg",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								children: item.body
							})
						]
					}) }, item.index))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: .12,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "mt-8",
						onClick: () => {
							navigate({ to: "/solutions" });
							window.scrollTo({
								top: 0,
								behavior: "smooth"
							});
						},
						children: ["All seven capabilities", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})
				})
			]
		})
	});
}
var ACTORS = [
	"UAV-04",
	"UAV-12",
	"ISL-07",
	"ISL-19",
	"GND-ALPHA",
	"GND-BRAVO",
	"SAT-K",
	"LEO-12",
	"RF-9",
	"HITL-RANGE",
	"POLAR-GATE"
];
var PROTOS = [
	"CCSDS",
	"MAVLINK",
	"S-BAND",
	"OPT-ISL",
	"1553B",
	"SPACEWIRE"
];
var SIGS = [
	"APT.ORBIT.7",
	"RF.INJECT.3",
	"MAV.SPOOF",
	"BUS.REPLAY",
	"KEY.DRIFT",
	"—"
];
function stamp(date = /* @__PURE__ */ new Date()) {
	return `${String(date.getUTCHours()).padStart(2, "0")}:${String(date.getUTCMinutes()).padStart(2, "0")}:${String(date.getUTCSeconds()).padStart(2, "0")}.${String(date.getUTCMilliseconds()).padStart(3, "0")}`;
}
var logSeq = 100;
function makeLog() {
	const roll = Math.random();
	const action = roll > .72 ? "BLOCK" : roll > .5 ? "WATCH" : roll > .22 ? "ALLOW" : "SCAN";
	return {
		id: logSeq++,
		time: stamp(),
		action,
		src: ACTORS[Math.floor(Math.random() * ACTORS.length)] ?? "UAV-04",
		dst: ACTORS[Math.floor(Math.random() * ACTORS.length)] ?? "ISL-07",
		proto: PROTOS[Math.floor(Math.random() * PROTOS.length)] ?? "CCSDS",
		sig: action === "ALLOW" || action === "SCAN" ? "—" : SIGS[Math.floor(Math.random() * SIGS.length)] ?? "—"
	};
}
function statusColor(status) {
	if (status === "alert") return palette.primary;
	if (status === "watch") return palette.muted;
	return palette.signal;
}
function actionClass(action) {
	if (action === "BLOCK") return "text-primary";
	if (action === "WATCH") return "text-muted";
	return "text-signal";
}
var PATHS = [
	"M 108 318 C 180 250, 280 230, 352 148",
	"M 168 214 C 260 160, 360 120, 430 78",
	"M 248 292 C 340 240, 430 200, 512 168",
	"M 318 42 C 380 90, 470 140, 556 268",
	"M 168 214 C 240 260, 400 250, 512 168"
];
var STATIC_LOGS = [
	{
		id: 1,
		time: "13:41:02.118",
		action: "ALLOW",
		src: "GND-ALPHA",
		dst: "UAV-12",
		proto: "MAVLINK",
		sig: "—"
	},
	{
		id: 2,
		time: "13:41:02.441",
		action: "SCAN",
		src: "POLAR-GATE",
		dst: "ISL-07",
		proto: "OPT-ISL",
		sig: "—"
	},
	{
		id: 3,
		time: "13:41:03.002",
		action: "BLOCK",
		src: "RF-9",
		dst: "ISL-19",
		proto: "S-BAND",
		sig: "RF.INJECT.3"
	},
	{
		id: 4,
		time: "13:41:03.510",
		action: "WATCH",
		src: "LEO-12",
		dst: "SAT-K",
		proto: "CCSDS",
		sig: "KEY.DRIFT"
	},
	{
		id: 5,
		time: "13:41:04.088",
		action: "ALLOW",
		src: "HITL-RANGE",
		dst: "GND-BRAVO",
		proto: "1553B",
		sig: "—"
	},
	{
		id: 6,
		time: "13:41:04.672",
		action: "BLOCK",
		src: "UAV-04",
		dst: "ISL-07",
		proto: "MAVLINK",
		sig: "MAV.SPOOF"
	},
	{
		id: 7,
		time: "13:41:05.201",
		action: "SCAN",
		src: "SAT-K",
		dst: "LEO-12",
		proto: "SPACEWIRE",
		sig: "—"
	},
	{
		id: 8,
		time: "13:41:05.844",
		action: "WATCH",
		src: "RF-9",
		dst: "GND-ALPHA",
		proto: "S-BAND",
		sig: "BUS.REPLAY"
	},
	{
		id: 9,
		time: "13:41:06.333",
		action: "ALLOW",
		src: "UAV-12",
		dst: "GND-BRAVO",
		proto: "MAVLINK",
		sig: "—"
	},
	{
		id: 10,
		time: "13:41:06.901",
		action: "BLOCK",
		src: "LEO-12",
		dst: "ISL-19",
		proto: "CCSDS",
		sig: "APT.ORBIT.7"
	},
	{
		id: 11,
		time: "13:41:07.414",
		action: "SCAN",
		src: "POLAR-GATE",
		dst: "SAT-K",
		proto: "OPT-ISL",
		sig: "—"
	},
	{
		id: 12,
		time: "13:41:08.002",
		action: "ALLOW",
		src: "HITL-RANGE",
		dst: "UAV-04",
		proto: "1553B",
		sig: "—"
	},
	{
		id: 13,
		time: "13:41:08.560",
		action: "WATCH",
		src: "ISL-07",
		dst: "LEO-12",
		proto: "OPT-ISL",
		sig: "KEY.DRIFT"
	},
	{
		id: 14,
		time: "13:41:09.118",
		action: "BLOCK",
		src: "RF-9",
		dst: "UAV-12",
		proto: "S-BAND",
		sig: "RF.INJECT.3"
	}
];
function ThreatMap() {
	const reduced = useReducedMotion();
	const [lines, setLines] = (0, import_react.useState)(STATIC_LOGS);
	const [selected, setSelected] = (0, import_react.useState)("leo-12");
	(0, import_react.useEffect)(() => {
		if (reduced) return;
		const id = window.setInterval(() => {
			setLines((prev) => [...prev.slice(-16), makeLog()]);
		}, 850);
		return () => window.clearInterval(id);
	}, [reduced]);
	const selectedNode = THREAT_NODES.find((n) => n.id === selected);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "scroll-mt-20 border-t border-border py-20 sm:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
					index: "04",
					label: "Telemetry"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 max-w-2xl text-3xl font-semibold tracking-[-0.03em] text-fg sm:text-4xl",
					children: "Real-time threat telemetry."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-base leading-relaxed text-muted",
					children: "A live picture of the fleet, the constellation, and the hostile spectrum — fused into one operator surface."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: .1,
				className: "mt-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-border bg-surface",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pulse-dot size-1.5 rounded-full bg-signal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-2xs uppercase tracking-[0.18em] text-muted",
								children: "Live · SRC SPACE/C2"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4 font-mono text-micro uppercase tracking-[0.14em] text-dim",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Events 24h ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-fg",
									children: "14,204"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Blocked ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-primary",
									children: "2,881"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZuluClock, { className: "tabular-nums text-muted" })
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative min-h-[320px] overflow-hidden border-b border-border lg:border-r lg:border-b-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									viewBox: "0 0 640 380",
									className: "h-full w-full",
									role: "img",
									"aria-label": "Tactical threat map with orbital and flight paths",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pattern", {
											id: "map-grid",
											width: "32",
											height: "32",
											patternUnits: "userSpaceOnUse",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
												d: "M 32 0 L 0 0 0 32",
												fill: "none",
												stroke: palette.border,
												strokeWidth: "0.6"
											})
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
											width: "640",
											height: "380",
											fill: palette.bg
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
											width: "640",
											height: "380",
											fill: "url(#map-grid)"
										}),
										[
											80,
											160,
											240,
											320
										].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
											x1: "0",
											x2: "640",
											y1: y,
											y2: y,
											stroke: palette.border,
											strokeDasharray: "2 10",
											opacity: "0.5"
										}, y)),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
											cx: "330",
											cy: "180",
											rx: "240",
											ry: "92",
											fill: "none",
											stroke: palette.signal,
											strokeOpacity: "0.28",
											transform: "rotate(-16 330 180)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
											cx: "330",
											cy: "180",
											rx: "190",
											ry: "64",
											fill: "none",
											stroke: palette.primary,
											strokeOpacity: "0.28",
											transform: "rotate(22 330 180)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
											cx: "330",
											cy: "180",
											rx: "270",
											ry: "118",
											fill: "none",
											stroke: palette.muted,
											strokeOpacity: "0.18",
											transform: "rotate(8 330 180)"
										}),
										PATHS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d,
											fill: "none",
											stroke: palette.signal,
											strokeOpacity: "0.45",
											strokeWidth: "1"
										}, d)),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
											x: "24",
											y: "28",
											fill: palette.muted,
											fontFamily: "JetBrains Mono, monospace",
											fontSize: "9",
											letterSpacing: "1.4",
											children: "THEATER · INDOPAC / LEO BELT"
										}),
										THREAT_NODES.map((node) => {
											const color = statusColor(node.status);
											const isSel = selected === node.id;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
												onClick: () => setSelected(node.id),
												className: "cursor-pointer",
												children: [
													node.status === "alert" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
														cx: node.x,
														cy: node.y,
														r: "12",
														fill: "none",
														stroke: color,
														className: "origin-center animate-ping",
														style: {
															transformBox: "fill-box",
															transformOrigin: "center"
														}
													}) : null,
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
														cx: node.x,
														cy: node.y,
														r: isSel ? 6 : 4,
														fill: color,
														stroke: palette.bg,
														strokeWidth: "1"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
														x: node.x + 10,
														y: node.y - 8,
														fill: isSel ? palette.fg : palette.muted,
														fontFamily: "JetBrains Mono, monospace",
														fontSize: "8",
														letterSpacing: "0.8",
														children: node.label
													})
												]
											}, node.id);
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scan-sweep pointer-events-none absolute inset-y-0 left-0 w-16 bg-linear-to-r from-transparent via-signal/10 to-transparent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute right-3 bottom-3 flex gap-3 font-mono text-micro uppercase tracking-[0.14em] text-dim",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-signal" }), " Secure"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-muted" }), " Watch"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-primary" }), " Alert"]
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-h-[280px] flex-col bg-bg",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between border-b border-border px-4 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-micro uppercase tracking-[0.16em] text-muted",
										children: "firewall / block log"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-micro text-signal",
										children: selectedNode ? selectedNode.label : "ALL NODES"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 overflow-hidden px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "space-y-1.5 font-mono text-2xs leading-5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
											initial: false,
											children: lines.slice(-12).map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.li, {
												initial: reduced ? false : {
													opacity: 0,
													y: 8
												},
												animate: {
													opacity: 1,
													y: 0
												},
												transition: {
													duration: .25,
													ease: [
														.22,
														1,
														.36,
														1
													]
												},
												className: "flex flex-wrap gap-x-2 text-dim",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "tabular-nums text-muted",
														children: line.time
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: cn("w-10", actionClass(line.action)),
														children: line.action
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-muted",
														children: [
															line.src,
															" → ",
															line.dst
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: line.proto }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-fg/80",
														children: line.sig
													})
												]
											}, line.id))
										})
									})
								}),
								selectedNode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "border-t border-border px-4 py-3 font-mono text-micro uppercase tracking-[0.14em] text-muted",
									children: [
										"Node ",
										selectedNode.label,
										" · ",
										selectedNode.status,
										" · uplink encrypted"
									]
								}) : null
							]
						})]
					})]
				})
			})]
		})
	});
}
function Research() {
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "research",
		className: "scroll-mt-20 border-t border-border py-20 sm:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
						index: "05",
						label: "Insights"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 max-w-2xl text-3xl font-semibold tracking-[-0.03em] text-fg sm:text-4xl",
						children: "Technical reports, released under control."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-base leading-relaxed text-muted",
						children: "Selected findings from the HITL range and on-orbit observation campaigns. Full papers ship over a cleared channel."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stagger, {
					className: "mt-10 divide-y divide-border border border-border",
					children: RESEARCH.slice(0, 3).map((paper) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaggerItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toast("Document queued", { description: `${paper.id} is available under NDA.` }),
						className: "flex w-full flex-col gap-2 bg-surface px-4 py-5 text-left transition-colors duration-150 hover:bg-surface-2 sm:flex-row sm:items-center sm:gap-6 sm:px-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-9 shrink-0 items-center justify-center border border-border text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-micro tracking-[0.12em] text-signal",
								children: paper.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 text-sm font-medium text-fg sm:text-base",
								children: paper.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-micro text-dim",
								children: paper.pages
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-micro tabular-nums text-muted",
								children: paper.date
							})
						]
					}) }, paper.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: .1,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "mt-8",
						onClick: () => {
							navigate({ to: "/insights" });
							window.scrollTo({
								top: 0,
								behavior: "smooth"
							});
						},
						children: ["Papers and press", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})
				})
			]
		})
	});
}
function About() {
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "about",
		className: "scroll-mt-20 border-t border-border py-20 sm:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[1.2fr_0.8fr] lg:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
					index: "06",
					label: "About"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-3xl font-semibold tracking-[-0.03em] text-fg sm:text-4xl",
					children: "Forged for aerospace. Secured for the future."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-xl text-base leading-relaxed text-muted",
					children: "aerosecurity.space designs the cyber-physical control plane for vehicles that cannot fail in the air. We sit at the intersection of embedded systems, RF, and orbital mesh networking — shipping software that assumes a hostile spectrum."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-base leading-relaxed text-muted",
					children: "The platform is dual-use by design: the same EDR agent that rides a NASA cFS stack on orbit hardens a tactical UAV fleet on the edge."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					className: "mt-8",
					onClick: () => {
						navigate({ to: "/about" });
						window.scrollTo({
							top: 0,
							behavior: "smooth"
						});
					},
					children: ["Who we are", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: .12,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "grid grid-cols-1 gap-px border border-border bg-border sm:grid-cols-2 lg:grid-cols-1",
					children: FACTS.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-surface px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-mono text-micro uppercase tracking-[0.16em] text-dim",
							children: fact.k
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-sm text-fg",
							children: fact.v
						})]
					}, fact.k))
				})
			})]
		})
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductMatrix, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Solutions, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreatMap, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Research, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {})
	] });
}
//#endregion
export { palette as n, routes_exports as t };
