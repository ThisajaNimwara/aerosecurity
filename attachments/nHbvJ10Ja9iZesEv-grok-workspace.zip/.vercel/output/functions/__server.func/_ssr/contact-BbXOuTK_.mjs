import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as ShieldCheck, r as Timer, s as Radio } from "../_libs/lucide-react.mjs";
import { r as COMPLIANCE } from "./router-DhaH2Qdo.mjs";
import { i as Reveal, n as ClearanceForm, r as PageShell } from "./reveal-DlvPhQQo.mjs";
import { t as PageHeader } from "./page-header-B6OFR9ws.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-BbXOuTK_.js
var import_jsx_runtime = require_jsx_runtime();
var CHANNELS = [
	{
		icon: ShieldCheck,
		title: "Cleared channel",
		body: "Every request routes to a specialist over an authenticated, encrypted path — no cold inboxes."
	},
	{
		icon: Timer,
		title: "Response time",
		body: "Official-domain requests are triaged within one business day."
	},
	{
		icon: Radio,
		title: "Active programs",
		body: "Already under contract? Use your existing program liaison instead of this form."
	}
];
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		index: "05",
		label: "Contact",
		title: "Open a secure channel.",
		intro: "Tell us what you are trying to protect — a UAV fleet, a constellation, or a tactical avionics stack — and a specialist will follow up on a cleared line."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-5xl px-4 pb-24 sm:px-6 sm:pb-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 border-t border-border pt-12 lg:grid-cols-[1fr_0.85fr] lg:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-border bg-surface p-6 sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs uppercase tracking-[0.18em] text-fg",
						children: "Clearance request"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-mono text-micro uppercase tracking-[0.14em] text-dim",
						children: "Classification: CUI // NOFORN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClearanceForm, { idPrefix: "contact" })
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: .1,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-6",
					children: [
						CHANNELS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-4 border-b border-border pb-6 last:border-b-0 last:pb-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 shrink-0 items-center justify-center border border-border bg-surface text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.icon, {
									className: "size-4.5",
									strokeWidth: 1.6
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold uppercase tracking-[0.1em] text-fg",
								children: c.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1.5 max-w-sm text-sm leading-relaxed text-muted",
								children: c.body
							})] })]
						}, c.title)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-micro uppercase tracking-[0.16em] text-dim",
								children: "Compliance"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: COMPLIANCE.map((badge) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "border border-border px-2 py-1 font-mono text-micro uppercase tracking-[0.12em] text-dim",
									children: badge
								}, badge))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid gap-px border border-border bg-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-surface px-5 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "font-mono text-micro uppercase tracking-[0.16em] text-dim",
									children: "Engineering"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm text-fg",
									children: "El Segundo, California"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-surface px-5 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "font-mono text-micro uppercase tracking-[0.16em] text-dim",
									children: "Range"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-sm text-fg",
									children: "Colorado Springs, Colorado"
								})]
							})]
						})
					]
				})
			})]
		})
	})] });
}
//#endregion
export { ContactPage as component };
