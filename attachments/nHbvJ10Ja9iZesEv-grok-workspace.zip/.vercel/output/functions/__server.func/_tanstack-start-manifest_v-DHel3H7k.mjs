//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DHel3H7k.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/export",
			"/insights",
			"/privacy",
			"/solutions",
			"/terms"
		],
		preloads: ["/assets/index-DPQle1SD.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DPQle1SD.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BqSBoY8Q.js",
			"/assets/reveal-dQPzTrvp.js",
			"/assets/file-text-DNeZfZFZ.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-B7HrCizo.js",
			"/assets/reveal-dQPzTrvp.js",
			"/assets/page-header-B_wmXVyu.js"
		]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-CMEc0ypL.js",
			"/assets/reveal-dQPzTrvp.js",
			"/assets/page-header-B_wmXVyu.js"
		]
	},
	"/export": {
		filePath: "/workspace/src/routes/export.tsx",
		children: void 0,
		preloads: [
			"/assets/export-CCqy-1Aa.js",
			"/assets/reveal-dQPzTrvp.js",
			"/assets/page-header-B_wmXVyu.js"
		]
	},
	"/insights": {
		filePath: "/workspace/src/routes/insights.tsx",
		children: void 0,
		preloads: [
			"/assets/insights-COcP9CHz.js",
			"/assets/reveal-dQPzTrvp.js",
			"/assets/file-text-DNeZfZFZ.js",
			"/assets/page-header-B_wmXVyu.js"
		]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-DpXpH_iN.js",
			"/assets/reveal-dQPzTrvp.js",
			"/assets/page-header-B_wmXVyu.js"
		]
	},
	"/solutions": {
		filePath: "/workspace/src/routes/solutions.tsx",
		children: void 0,
		preloads: [
			"/assets/solutions-CFHuivIl.js",
			"/assets/reveal-dQPzTrvp.js",
			"/assets/page-header-B_wmXVyu.js"
		]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-CQYq6zD1.js",
			"/assets/reveal-dQPzTrvp.js",
			"/assets/page-header-B_wmXVyu.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
